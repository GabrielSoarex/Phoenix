<?php
    include 'conect.php';

    $action = $_POST['acao']; 

    if($action == 'add'){
        $nome = $_POST['nome'];
        $sobrenome = $_POST['sobrenome'];
        $email = $_POST['email'];
        $mensagem = $_POST['mensagem'];

        $sql = "INSERT INTO tbcliente VALUES ('$nome', '$sobrenome', '$email',  '$mensagem')"; 

        $resultado = mysqli_query($conexao, $sql);

        echo"<script> alert( 'Cadastro efetuado'); </script>";
        include 'index.html';

    }
?> 