<?php
$servidor="127.0.0.1";
$usuario="root";
$senha="";
$banco="bdcliente"; 

$conexao = mysqli_connect($servidor, $usuario, $senha,$banco) or die(mysqli_error());

?>